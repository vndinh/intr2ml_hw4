function [seq,state] = hmm_seq_generator(A, B,prior)
% Generate a data sequence from a hidden Markov model.
% Input:
%   A: state transition probability distribution
%   B: observation symbol probability distribution
%   prior: initial state distribution
% Output:
%   seq: sequence
%   state: states

% based on pi (prior), selecting starting state
z = discreteRnd(prior);

% oboservation symbol probability based sampling
i = 1;
seq(i) = discreteRnd(B(z,:));
state(i) = z;

while z < 3
    % state transition probability based state change
    z = discreteRnd(A(z,:));
    
    % oboservation symbol probability based sampling
    i = i + 1;
    state(i) = z;
    
    % given state 1, sample with prob. of b_1(v_k)
    % v_k : b_1(v_{k-1}) <= rand() < b_1(v_k)
    seq(i) = discreteRnd(B(z,:));
    
    % terminal state
    if z == 3
        break;
    end
end