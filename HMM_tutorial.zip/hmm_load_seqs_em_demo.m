%% hmm tutorial
% 2018/06/11

% demo for HMM
clear all;
clc;

% number of samples
N = 10;
num_observation = 6;

%% lambda for hmm model 1
A1 = [0.8, 0.2, 0.0;
      0.0, 0.7, 0.3;
      0.0, 0.0, 0.0];
B1 = [1/6,  1/6,  1/6,  1/6,  1/6, 1/6;
     1/10, 1/10, 1/10, 1/10, 1/10, 1/2;
     1/10, 1/10, 1/10, 1/10, 1/10, 1/2];
pi1 = [1.0; 0.0; 0.0]; % prior (pi)

load data1
load state_data1
load test_data1
load test_state_data1

%% lambda for hmm model 2
A2 = [0.6, 0.2, 0.2;
      0.0, 0.6, 0.4;
      0.0, 0.0, 0.0];
B2 = [1/6,  1/6,  1/6,  1/6,  1/6, 1/6;
     1/10, 1/10, 1/10, 1/10, 1/10, 1/2;
     1/10, 1/10, 1/10, 1/10, 1/10, 1/2];
pi2 = [1.0; 0.0; 0.0]; % prior (pi)

load data2
load state_data2
load test_data2
load test_state_data2


%% scoring
% HMM for class '1' and random initialization of parameters
% hmm1 = 
%       prior: [3��1 double]
%    transmat: [3��3 double] --> A
%      obsmat: [3��16 double]--> B
num_hmm1_state = 3;
hmm1.prior = [1 0 0];
hmm1.transmat = rand(num_hmm1_state,num_hmm1_state); % 3 by 3 transition matrix
hmm1.transmat(num_hmm1_state-1,1) =0; 
hmm1.transmat(num_hmm1_state,1) = 0; 
hmm1.transmat(num_hmm1_state,2) = 0;
hmm1.transmat(num_hmm1_state,3) = 0;
hmm1.transmat = mk_stochastic(hmm1.transmat);
hmm1.obsmat = rand(num_hmm1_state, num_observation); % # of states * # of observation
hmm1.obsmat = mk_stochastic(hmm1.obsmat);

%% Training of HMM model 1 (Baum-Welch algorithm)
% ======== inputs ============
% data1 : sequence input
% hmm1.prior: initial model prior
% hmm1.transmat (A): initial model transmat 
% hmm1.obsmat (B): initial obsmat
% ======== outputs ===========
% LL1 : loglikelihood of the observation
% hmm1.prior : updated model prior
% hmm1.transmat (A): updated model transmat 
% hmm1.obsmat (B): updated model obsmat
[LL1, hmm1.prior, hmm1.transmat, hmm1.obsmat] = dhmm_em(data1, hmm1.prior,hmm1.transmat, hmm1.obsmat);

% smoothing of HMM observation parameter: set floor value 1.0e-5
hmm1.obsmat = max(hmm1.obsmat, 1.0e-5);

% HMM for class '2' and random initialiation of parameters
% hmm2 = 
%       prior: [2��1 double]
%    transmat: [2��2 double] --> A
%      obsmat: [2��16 double]--> B
num_hmm2_state = 3;
hmm2.prior = [1 0 0];
hmm2.transmat = rand(num_hmm2_state,num_hmm2_state); % 2 by 2 transition matrix
hmm2.transmat(num_hmm2_state-1,1) = 0;
hmm2.transmat(num_hmm2_state,1) = 0;
hmm2.transmat(num_hmm2_state,2) = 0;
hmm2.transmat(num_hmm2_state,3) = 0;
hmm2.transmat = mk_stochastic(hmm2.transmat);
hmm2.obsmat = rand(num_hmm2_state, num_observation); % # of states * # of observation
hmm2.obsmat = mk_stochastic(hmm2.obsmat);

% Training of HMM model 2 (Baum-Welch algorithm)
% ======== inputs ============
% data2 : sequence input
% hmm2.prior: initial model prior
% hmm2.transmat (A): initial model transmat 
% hmm2.obsmat (B): initial obsmat
% ======== outputs ===========
% LL2 : loglikelihood of the observation
% hmm2.prior : updated model prior
% hmm2.transmat (A): updated model transmat 
% hmm2.obsmat (B): updated model obsmat
[LL2, hmm2.prior, hmm2.transmat, hmm2.obsmat] = dhmm_em(data2, hmm2.prior,hmm2.transmat, hmm2.obsmat);

% smoothing of HMM observation parameter: set floor value 1.0e-5
hmm2.obsmat = max(hmm2.obsmat, 1.0e-5);

%% Compare model likelihood and accuracy
acc = 0;
%Evaluation of class '0' data
for dt =1:length(test_data1)
    loglike1 = dhmm_logprob(test_data1{dt}, hmm1.prior, hmm1.transmat, hmm1.obsmat);
    loglike2 = dhmm_logprob(test_data1{dt}, hmm2.prior, hmm2.transmat, hmm2.obsmat);
    if exp(loglike1) > exp(loglike2)
        pred_cls = 1;
        acc = acc + 1;
    else
        pred_cls = 2;
    end
    disp(sprintf('[class 1: %d-th data] model 0: %f, model 1: %f, predicted class:%d',dt, exp(loglike1), exp(loglike2), pred_cls));
end
for dt =1:length(test_data2)
    loglike1 = dhmm_logprob(test_data2{dt}, hmm1.prior, hmm1.transmat, hmm1.obsmat);
    loglike2 = dhmm_logprob(test_data2{dt}, hmm2.prior, hmm2.transmat, hmm2.obsmat);
    if exp(loglike1) > exp(loglike2)
        pred_cls = 1;
    else
        pred_cls = 2;
        acc = acc + 1;
    end
    disp(sprintf('[class 1: %d-th data] model 0: %f, model 1: %f, predicted class:%d',dt, exp(loglike1), exp(loglike2), pred_cls));
end

%% Viterbi path decoding
%First you need to evaluate B(i,t) = P(y_t | Q_t=i) for all t,i:

path1 = cell(1, length(data1));
for dt =1:length(data1)
    B = multinomial_prob(data1{dt}, hmm1.obsmat);
    path1{dt} = viterbi_path(hmm1.prior, hmm1.transmat, B);
    disp(sprintf('%d', path1{dt}));
end

path2 = cell(1, length(data2));
for dt =1:length(data2)
    B = multinomial_prob(data2{dt}, hmm2.obsmat);
    path2{dt} = viterbi_path(hmm2.prior, hmm2.transmat, B);
    disp(sprintf('%d', path2{dt}));
end

disp(['test_acc:', num2str(acc/(2*length(test_data1)))]);

hmm1.transmat
hmm1.obsmat

hmm2.transmat
hmm2.obsmat